import { q, type Row } from './db';
import { newId, errMessage, truncate } from './util';
import { j } from './db';
import { getSources, renderInput, type SearchQuery } from './sources';
import { startRun, getRun, getItems, TERMINAL_FAIL, ApifyError } from './apify';
import { normalizeItem, matchesKeywords, type NormJob } from './normalize';
import { iso, listJobs, upsertJobs } from './jobs';

const RUN_TIMEOUT_MIN = 15;

export interface RunView {
  id: string;
  source: string;
  actor: string;
  status: 'running' | 'ingesting' | 'done' | 'failed';
  error: string | null;
  found: number;
  added: number;
  started_at: string | null;
}

export interface SearchView {
  id: string;
  query: SearchQuery;
  status: 'running' | 'done' | 'partial' | 'failed';
  created_at: string | null;
  runs: RunView[];
  found: number;
  added: number;
}

function mapRun(r: Row): RunView {
  return {
    id: r.id,
    source: r.source,
    actor: r.actor,
    status: r.status,
    error: r.error ?? null,
    found: r.found ?? 0,
    added: r.added ?? 0,
    started_at: iso(r.started_at),
  };
}

export async function startSearch(query: SearchQuery): Promise<SearchView> {
  const sources = (await getSources()).filter((s) => s.enabled && (!query.sources?.length || query.sources.includes(s.id)));
  if (!sources.length) throw new Error('No sources are enabled. Turn one on in Settings → Sources.');
  const searchId = newId('s');
  await q('INSERT INTO searches (id, query) VALUES ($1, $2::jsonb)', [searchId, j(query)]);

  await Promise.all(
    sources.map(async (s) => {
      const runId = newId('r');
      try {
        const input = renderInput(s.input, query, s.maxResults);
        const run = await startRun(s.actor, input);
        await q(
          `INSERT INTO search_runs (id, search_id, source, actor, apify_run_id, dataset_id, status)
           VALUES ($1,$2,$3,$4,$5,$6,'running')`,
          [runId, searchId, s.id, s.actor, run.id, run.datasetId],
        );
      } catch (e) {
        await q(
          `INSERT INTO search_runs (id, search_id, source, actor, status, error, finished_at)
           VALUES ($1,$2,$3,$4,'failed',$5, now())`,
          [runId, searchId, s.id, s.actor, truncate(errMessage(e), 600)],
        );
      }
    }),
  );
  return advanceSearch(searchId);
}

async function ingestRun(run: Row, query: SearchQuery, localFilter: boolean, searchId: string): Promise<void> {
  const claimed = await q(`UPDATE search_runs SET status = 'ingesting' WHERE id = $1 AND status = 'running' RETURNING id`, [run.id]);
  if (!claimed.length) return; // another request is already ingesting it
  try {
    const items = await getItems(run.dataset_id, 500);
    const jobs: NormJob[] = [];
    for (const it of items) {
      const n = normalizeItem(run.source, it);
      if (n) jobs.push(n);
    }
    const kept = localFilter ? jobs.filter((x) => matchesKeywords(x, query.keywords)) : jobs;
    const res = await upsertJobs(searchId, kept);
    await q(`UPDATE search_runs SET status = 'done', found = $2, added = $3, finished_at = now() WHERE id = $1`, [
      run.id,
      kept.length,
      res.added,
    ]);
  } catch (e) {
    await q(`UPDATE search_runs SET status = 'failed', error = $2, finished_at = now() WHERE id = $1`, [
      run.id,
      truncate(errMessage(e), 600),
    ]);
  }
}

/** Checks Apify for progress, ingests finished runs, and returns the current state. Safe to call repeatedly. */
export async function advanceSearch(searchId: string): Promise<SearchView> {
  const s = await q('SELECT * FROM searches WHERE id = $1', [searchId]);
  if (!s.length) throw new Error('Search not found.');
  const query = s[0].query as SearchQuery;
  const sources = await getSources();
  let runs = await q('SELECT * FROM search_runs WHERE search_id = $1 ORDER BY started_at', [searchId]);

  await Promise.all(
    runs
      .filter((r) => r.status === 'running' && r.apify_run_id)
      .map(async (r) => {
        try {
          const info = await getRun(r.apify_run_id);
          if (info.status === 'SUCCEEDED') {
            const cfg = sources.find((x) => x.id === r.source);
            await ingestRun(r, query, !!cfg?.localKeywordFilter, searchId);
          } else if (TERMINAL_FAIL.has(info.status)) {
            await q(`UPDATE search_runs SET status='failed', error=$2, finished_at=now() WHERE id=$1 AND status='running'`, [
              r.id,
              `Apify run ${info.status.toLowerCase()}${info.statusMessage ? `: ${info.statusMessage}` : ''}`,
            ]);
          } else if (Date.now() - new Date(r.started_at).getTime() > RUN_TIMEOUT_MIN * 60_000) {
            await q(`UPDATE search_runs SET status='failed', error=$2, finished_at=now() WHERE id=$1 AND status='running'`, [
              r.id,
              `Still running after ${RUN_TIMEOUT_MIN} minutes; gave up waiting.`,
            ]);
          }
        } catch (e) {
          // transient Apify/network errors: leave the run as running, except hard failures
          if (e instanceof ApifyError && (e.status === 401 || e.status === 404)) {
            await q(`UPDATE search_runs SET status='failed', error=$2, finished_at=now() WHERE id=$1 AND status='running'`, [
              r.id,
              truncate(e.message, 600),
            ]);
          }
        }
      }),
  );

  runs = await q('SELECT * FROM search_runs WHERE search_id = $1 ORDER BY started_at', [searchId]);
  const pending = runs.some((r) => r.status === 'running' || r.status === 'ingesting');
  let status: SearchView['status'] = 'running';
  if (!pending) {
    const okCount = runs.filter((r) => r.status === 'done').length;
    status = okCount === runs.length ? 'done' : okCount === 0 ? 'failed' : 'partial';
    await q(`UPDATE searches SET status = $2, finished_at = COALESCE(finished_at, now()) WHERE id = $1`, [searchId, status]);
  }
  const views = runs.map(mapRun);
  return {
    id: searchId,
    query,
    status,
    created_at: iso(s[0].created_at),
    runs: views,
    found: views.reduce((a, r) => a + r.found, 0),
    added: views.reduce((a, r) => a + r.added, 0),
  };
}

export async function listSearches(limit = 20): Promise<SearchView[]> {
  const rows = await q('SELECT id FROM searches ORDER BY created_at DESC LIMIT $1', [limit]);
  const out: SearchView[] = [];
  for (const r of rows) {
    const s = await q('SELECT * FROM searches WHERE id = $1', [r.id]);
    const runs = (await q('SELECT * FROM search_runs WHERE search_id = $1 ORDER BY started_at', [r.id])).map(mapRun);
    out.push({
      id: r.id,
      query: s[0].query,
      status: s[0].status,
      created_at: iso(s[0].created_at),
      runs,
      found: runs.reduce((a, x) => a + x.found, 0),
      added: runs.reduce((a, x) => a + x.added, 0),
    });
  }
  return out;
}

export async function jobsForSearch(searchId: string, limit = 50) {
  return listJobs({ searchId, sort: 'newest', limit, state: 'active' });
}
